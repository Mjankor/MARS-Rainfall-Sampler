This library was imported from mercurial on 2012/01/18 (v1.5)
by Marc MERLIN <marc_soft<at>merlins.org> to upload to github.
https://github.com/marcmerlin/NewLiquidCrystal

Original source and documention is here:
http://hg.bijland.net/fmalpartida/new-liquidcrystal
https://bitbucket.org/fmalpartida/new-liquidcrystal/wiki/Home
